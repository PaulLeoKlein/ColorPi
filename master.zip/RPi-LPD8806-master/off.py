#!/usr/bin/python

from bootstrap import *

led.all_off()



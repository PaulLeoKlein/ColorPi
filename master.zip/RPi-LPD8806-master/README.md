THIS LIBRARY IS DEPRECATED!!!
Please check out the new library, [BiblioPixel](https://github.com/ManiacalLabs/BiblioPixel).
Many, many more features and support for far more than the LPD8806!
